---
title: "Example Post"
date: "2025-11-01"
summary: "Placeholder blog post demonstrating the CMS workflow."
---
This is a placeholder blog post. Edit this content via the Admin panel once you set up Decap CMS and GitHub OAuth. Add images, change the date, and publish when you're ready.
